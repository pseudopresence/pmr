function o = foptions

    o = zeros(1, 18);
    o(2) = 1e-4;
    o(3) = 1e-4;
    o(4) = 1e-6;
    o(16) = 1e-8;
    
end